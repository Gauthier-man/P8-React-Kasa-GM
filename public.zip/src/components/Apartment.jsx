import React from 'react'
import "./Apartment.css"

function Apartment() {
  return (
    <div className="apartment">
      <div className="apartment__subtitle">Titre de la location</div>
    </div>
  )
}

export default Apartment
